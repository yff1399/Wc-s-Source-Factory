﻿using System.Windows;
using YuiMvvm.ViewModel;

namespace YuiMvvm
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region 字段

        public double top { get; set; }
        public double left { get; set; }
        public double width { get; set; }
        public double height { get; set; }

        #endregion

        public MainWindow()
        {
            InitializeComponent();
            Closing += (s, e) => ViewModelLocator.Cleanup();
        }

        private void Btn_Close_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Btn_Max_Click(object sender, RoutedEventArgs e)
        {
            left = this.Left;
            top = this.Top;
            width = this.Width;
            height = this.Height;

            this.Left = 0;
            this.Top = 0;
            Rect rc = SystemParameters.WorkArea;//获取工作区大小
            this.Width = rc.Width;
            this.Height = rc.Height;
            Btn_Max.Visibility = Visibility.Collapsed;
        }

        private void Btn_Min_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Btn_Restore_Click(object sender, RoutedEventArgs e)
        {
            //this.Left = left;
            //this.Top = width;
            //this.Width = width;
            //this.Height = height;
            this.WindowState = WindowState.Normal;
        }

        private void Grid_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Grid_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            
        }

        private void Btn_Change_Click(object sender, RoutedEventArgs e)
        {
            popUp.IsOpen = true;
        }
    }
}
