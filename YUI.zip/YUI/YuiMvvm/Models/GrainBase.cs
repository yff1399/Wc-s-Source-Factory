﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YuiMvvm.Models
{
    /// <summary>
    /// 粒子类
    /// </summary>
    public class GrainBase
    {
        public double? x { get; set; }
        public double? y { get; set; }

        public double xa { get; set; }

        public double ya { get; set; }

        public double max { get; set; }

    }
}
